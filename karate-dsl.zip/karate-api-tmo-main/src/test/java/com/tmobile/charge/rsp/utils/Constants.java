package com.tmobile.charge.rsp.utils;

public class Constants {

	public static final String JSON_EXTENSION = ".json";
	public static final String NEWLINE = "\n";
	public static final String HYPHEN_SEPARATOR = "-------------------------------------------------------------";
	public static final String EQUALS_SEPARATOR = "=============================================================";
	public static final String EMPTY_STRING = "";
	public static final String UPLOAD_QTEST = "upload.qtest";

	public static final String PATTERN = "'(.*?)'";
	public static final String TEMP_FILE = "temp.txt";

	public static final String PASS = "PASS";
	public static final String FAIL = "FAIL";
	public static final String passed = "passed";
	public static final String PASSED = "PASSED";
	public static final String MATCH = "match ";
	public static final String STATUS_200 = "status 200";
	public static final String AND = " and ";
	public static final String PRINT = "[print] ";
	public static final String PRINT_RESPONSE = "print response";
	public static final String KARATE_ENV = "karate.env";
	public static final String REQUIREMENT_ID = "karate.requirementid";
	public static final String WORSHEET_CONTAINS_DATA = " Worksheet contains data ";
	public static final String AUTOMATION_REPORT = "Karate Automation Report";
	public static final String ENVIRONMENT = "Environment";

	public static final String STARTED_QTEST_INTEGRATION = " Started Qtest Integration ";
	public static final String COMPLETED_QTEST_INTEGRATION = " Completed Qtest Integration ";
	public static final String STARTED_WRITING_QTEST_FILES = " Started writing Qtest json files for ";
	public static final String COMPLETED_WRITING_QTEST_FILES = " Completed writing Qtest json files for ";

	public static final String JSON_OBEJCTS_FOLDER = "src/main/resources/json-objects/";
	public static final String JSON_E2E_OBEJCTS_FOLDER = "src/main/resources/json-e2e-objects/";
	public static final String UPLOAD_FEATURE_FILE = "classpath:com/tmobile/charge/rsp/feature/uploadtestresult.feature";
	public static final String UPLOAD_E2E_FEATURE_FILE = "classpath:com/tmobile/charge/rsp/feature/uploadteste2eresult.feature";

	public static final String FILE_DELETE_SUCESS = "File deleted successfully";
	public static final String FILE_DELETE_FAILED = "Failed to delete the file";
	public static final String APOSTROPHE = "'";
	public static final String TEST = "Test";
	public static final String FILENAME = "Filename == ";
	public static final String LOCATION = "Location == ";
	public static final String QTEST_OBJECT = "QTestFeaturesObject == ";
	public static final String NO_OF_FEATURE_FILES = "Number of feature files == ";
	public static final String APPLICATION_NAME = "Application name == ";
	public static final String TEST_STEPS = "TestSteps == ";
	public static final String FEATURE_NAME = "FeatureName == ";
	public static final String FEATURE_SECTION_NAME = "Feature Section name == ";
	public static final String HASHMAP_KEY = "Hash key == ";
	public static final String QTEST_JSON = "QTEST_JSON ==";
	public static final String QTEST_APPLICATION_NAME = "DSG (App Group)-DSG CHARGE (103923)";
	public static final String QTEST_CATEGORY = "Functional";
	public static final String QTEST_AUTOMATION_SYSTEM = "Tosca";
	public static final String QTEST_ENV = "prod";
	public static final String E2E = "E2E";

	public static final String JSON_PROCESSING_EXCEPTION = "Error occured while processing the json";
	public static final String IO_EXCEPTION = "Error occured while writing the json files to json-objects folder";

}
