package com.tmobile.charge.rsp.utils;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Utils {
	private static final Logger logger = LoggerFactory.getLogger(Utils.class);
	public void cleanDirectory(String dir) {
		try {
			FileUtils.cleanDirectory(Paths.get(dir).toFile());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	public void removeFile(String dir ) {
		Path filePath = Paths.get(dir + "uploadurl.json");

		if ((filePath.toFile()).delete()) {
			logger.info(Constants.FILE_DELETE_SUCESS);
		} else {
			logger.info(Constants.FILE_DELETE_FAILED);
		}

	}

}
