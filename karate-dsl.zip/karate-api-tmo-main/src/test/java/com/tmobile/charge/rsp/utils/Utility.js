function(config) {
  var utils = {};
  utils.uuid = function(){ return java.util.UUID.randomUUID() + '' };
  utils.writeFile = function(keyValue, file) { karate.write(keyValue, file); }
  utils.randomId = function(){ return Math.floor(Math.random() * 10000);}
  config.utils = karate.toMap(utils);
  return config;
}