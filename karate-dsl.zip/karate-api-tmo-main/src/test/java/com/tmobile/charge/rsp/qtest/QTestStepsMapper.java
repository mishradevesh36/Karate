package com.tmobile.charge.rsp.qtest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.tmobile.tep.enumeration.TestStepStatus;
import com.tmobile.tep.reporting.TestStepDTO;

@JsonIgnoreProperties(value = { "qtestDataDTO", "testStepDTO" })
public class QTestStepsMapper {

	private String description;
	private Integer order;
	private String expected;
	private String actualResult;

	private String status;
	private TestStepDTO testStepDTO;

	public void setTestStepDTO(TestStepDTO testStepDTO) {
		this.testStepDTO = testStepDTO;
	}

	public TestStepDTO getTestStepDTO() {
		return testStepDTO;
	}

	public void setDescription(TestStepDTO testStepDTO) {
		this.description = testStepDTO.getDescription();
	}

	public String getDescription() {
		return description;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setOrder(TestStepDTO testStepDTO) {
		this.order = testStepDTO.getOrder();
	}

	public Integer getOrder() {
		return order;
	}

	public void setExpected(String expected) {
		this.expected = expected;
	}

	public String getExpected() {
		return expected;
	}

	public void setActualResult(String actualResult) {
		this.actualResult = actualResult;
	}

	public String getActualResult() {
		return actualResult;
	}

}
