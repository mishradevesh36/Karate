package com.tmobile.charge.rsp.qtest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.tmobile.tep.qtest.QTestUpdateDTO;

import java.util.List;

@JsonIgnoreProperties(value = { "qTestUpdateDTO" })
public class QTestUpdateDTOMapper {

	private String duId;
	private String notes;
	private String status;
	private String reason;
	private String testEnv;
	private String testType;
	private String qTestBuildMode="prod";
	private String qTestAutomationRefId;
	private long qTestProjectId;
	private long qTestTestSuiteId;
	private boolean logTestSteps=true;

	private List<QTestStepsMapper> testSteps;


	public void setTestSteps(List<QTestStepsMapper> testSteps) {
		this.testSteps = testSteps;
	}

	public List<QTestStepsMapper> getTestSteps() {
		return testSteps;
	}

	public boolean isLogTestSteps() {
		return logTestSteps;
	}

	public void setLogTestSteps(boolean logTestSteps) {
		this.logTestSteps = logTestSteps;
	}

	public void setQTestProjectId(QTestUpdateDTO qTestUpdateDTO) {
		this.qTestProjectId = qTestUpdateDTO.getQTestProjectId();
	}

	public long getQTestProjectId() {
		return qTestProjectId;
	}

	public void setQTestTestSuiteId(QTestUpdateDTO qTestUpdateDTO) {
		this.qTestTestSuiteId = qTestUpdateDTO.getQTestTestSuiteId();
	}

	public long getQTestTestSuiteId() {
		return qTestTestSuiteId;
	}

	public void setStatus(QTestUpdateDTO qTestUpdateDTO) {
		this.status = qTestUpdateDTO.getStatus();
	}

	public String getStatus() {
		return status;
	}

	public void setQTestBuildMode(QTestUpdateDTO qTestUpdateDTO) {
		this.qTestBuildMode = qTestUpdateDTO.getQTestBuildMode();
	}

	public String getQTestBuildMode() {
		return qTestBuildMode;
	}

	public void setNotes(QTestUpdateDTO qTestUpdateDTO) {
		this.notes = qTestUpdateDTO.getNotes();
	}

	public String getNotes() {
		return notes;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(QTestUpdateDTO qTestUpdateDTO) {
		this.reason = qTestUpdateDTO.getReason();
	}

	public void setQTestAutomationRefId(QTestUpdateDTO qTestUpdateDTO) {
		this.qTestAutomationRefId = qTestUpdateDTO.getqTestAutomationRefId();
	}

	public String getQTestAutomationRefId() {
		return qTestAutomationRefId;
	}

	public String getTestEnv() {
		return testEnv;
	}

	public void setTestEnv(String testEnv) {
		this.testEnv = testEnv;
	}

	public String getTestType() {
		return testType;
	}

	public void setTestType(String testType) {
		this.testType = testType;
	}

	public String getDuId() {
		return duId;
	}

	public void setDuId(String duId) {
		this.duId = duId;
	}

}
