package com.tmobile.charge.rsp.qtest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.tmobile.tep.qtest.QTestDataDTO;

@JsonIgnoreProperties(value = { "qtestDataDTO" })
public class QTestDataDtoMapper {

	private long projectId;
	private long moduleId;
	private String automationReferenceId;
	private QTestDataDTO qtestDataDTO;

	public QTestDataDtoMapper() {
		super();
	}

	public void setQtestDataDTO(QTestDataDTO qtestDataDTO) {
		this.qtestDataDTO = qtestDataDTO;
	}

	public QTestDataDTO getQtestDataDTO() {
		return qtestDataDTO;
	}

	public void setProjectId(String projectId) {
		this.projectId = qtestDataDTO.getQTestProjectId();
	}

	public long getProjectId() {
		return projectId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = qtestDataDTO.getQTestModuleId();
	}

	public long getModuleId() {
		return moduleId;
	}

	public void setAutomationReferenceId(String automationReferenceId) {
		this.automationReferenceId = qtestDataDTO.getqTestAutomationRefId();
	}

	public String getAutomationReferenceId() {
		return automationReferenceId;
	}

}
