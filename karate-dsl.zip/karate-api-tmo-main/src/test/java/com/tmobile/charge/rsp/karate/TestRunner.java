package com.tmobile.charge.rsp.karate;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intuit.karate.KarateOptions;
import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import com.intuit.karate.core.ScenarioResult;
import com.intuit.karate.core.StepResult;
import com.intuit.karate.junit5.Karate.Test;
import com.tmobile.charge.rsp.qtest.QTestObjectMapper;
import com.tmobile.charge.rsp.qtest.QTestStepsMapper;
import com.tmobile.charge.rsp.qtest.QTestUpdateDTOMapper;
import com.tmobile.charge.rsp.qtest.WorkSheetQTestAttributeMapper;
import com.tmobile.charge.rsp.utils.Constants;
import com.tmobile.tep.enumeration.TestStepStatus;
import com.tmobile.tep.qtest.QTestDataDTO;
import com.tmobile.tep.qtest.QTestUpdateDTO;
import com.tmobile.tep.reporting.TestStepDTO;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;


@KarateOptions(features = {
		"classpath:com/tmobile/charge/rsp/feature/addresslookup.feature",
		"classpath:com/tmobile/charge/rsp/feature/addressverification.feature",
		"classpath:com/tmobile/charge/rsp/feature/addressupdate.feature",
		"classpath:com/tmobile/charge/rsp/feature/billdetails.feature",
		"classpath:com/tmobile/charge/rsp/feature/billhistory.feature",
		"classpath:com/tmobile/charge/rsp/feature/billsummary.feature",
		"classpath:com/tmobile/charge/rsp/feature/npanxxlookup.feature",
		"classpath:com/tmobile/charge/rsp/feature/numbermanagement.feature",
		"classpath:com/tmobile/charge/rsp/feature/orderfulfillment.feature",
		"classpath:com/tmobile/charge/rsp/feature/passagreement.feature",
		"classpath:com/tmobile/charge/rsp/feature/serviceagreement.feature",
		"classpath:com/tmobile/charge/rsp/feature/subscriber.feature",
		"classpath:com/tmobile/charge/rsp/feature/subscribercontract.feature",
		"classpath:com/tmobile/charge/rsp/feature/subscriberdetail.feature",
		"classpath:com/tmobile/charge/rsp/feature/subscriberupdate.feature",
		"classpath:com/tmobile/charge/rsp/feature/capability-memo.feature",
		"classpath:com/tmobile/charge/rsp/feature/orderfulfillmentnotifications.feature",
		"classpath:com/tmobile/charge/rsp/feature/service-sms.feature",
		"classpath:com/tmobile/charge/rsp/feature/service-email.feature",
		"classpath:com/tmobile/charge/rsp/feature/experience-receipt.feature",
		"classpath:com/tmobile/charge/rsp/feature/experience-servicequote.feature",
		"classpath:com/tmobile/charge/rsp/feature/service-samson.feature",
		"classpath:com/tmobile/charge/rsp/feature/salesmetrics.feature",
		"classpath:com/tmobile/charge/rsp/feature/voicereminderjob.feature",
		"classpath:com/tmobile/charge/rsp/feature/storesalesmetricsprocessor.feature",
		"classpath:com/tmobile/charge/rsp/feature/cancelbusinessorderprocessor.feature",
		"classpath:com/tmobile/charge/rsp/feature/eipvoicereminderftpjob.feature",
		"classpath:com/tmobile/charge/rsp/feature/processorderconsumer.feature",
		"classpath:com/tmobile/charge/rsp/feature/orderfulfillmentprocessor.feature",
		"classpath:com/tmobile/charge/rsp/feature/service-receiptnotification.feature",
		"classpath:com/tmobile/charge/rsp/feature/addbandollaradjustment.feature"
	})
public class TestRunner {

	private static final Logger logger = LoggerFactory.getLogger(TestRunner.class);
	private static String environment = System.getProperty(Constants.KARATE_ENV);
	private static String requirementId = System.getProperty(Constants.REQUIREMENT_ID);
	private static String uploadQtest = System.getProperty(Constants.UPLOAD_QTEST);

	private Map<String, WorkSheetQTestAttributeMapper> mapWorksheet = new HashMap<>();

	@Test
	public void testParallel() throws IOException, InterruptedException {
		Results results = Runner.parallel(getClass(), 100);
		generateReport(results.getReportDir());
		System.setProperty("karate.options", Constants.EMPTY_STRING);
		if (uploadQtest != null && Boolean.parseBoolean(uploadQtest)) {
			uploadQtestResults(results);
			cleanDirectory(Constants.JSON_E2E_OBEJCTS_FOLDER);
			cleanDirectory(Constants.JSON_OBEJCTS_FOLDER);
		}
	}

	private void generateReport(String karateOutputPath) {
		try {
			Collection<File> jsonFiles = org.apache.commons.io.FileUtils.listFiles(new File(karateOutputPath),
					new String[] { "json" }, true);
			List<String> jsonPaths = new ArrayList<>(jsonFiles.size());
			jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
			Configuration config = new Configuration(new File("target"), Constants.AUTOMATION_REPORT);
			config.addClassifications(Constants.ENVIRONMENT, environment != null ? environment.toUpperCase() : null);
			ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
			reportBuilder.generateReports();
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex.getMessage());
		}
	}

	private void writeToUploadJsonFile(String content, String dir) {
		try {
			logger.info(" Creating Upload URL JSON file in DIR "+dir);
			PrintWriter out = new PrintWriter(Paths.get(dir+ "uploadurl.json").toFile());
			out.println(content);
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void removeFile(String filename, String dir ) {
		Path filePath = Paths.get(dir+ filename);
		if ((filePath.toFile()).delete()) {
			logger.info(Constants.FILE_DELETE_SUCESS);
		} else {
			logger.info(Constants.FILE_DELETE_FAILED);
		}
	}

	private void cleanDirectory(String dir ) {
		try {
			FileUtils.cleanDirectory(Paths.get(dir).toFile());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void updateUploadurlsFile(String dir) {
		Path filePath = Paths.get(dir + Constants.TEMP_FILE);
		String content = Constants.EMPTY_STRING;
		try {
			content = (new String(Files.readAllBytes(filePath))).replaceAll(",$", "");
			writeToUploadJsonFile("[" + content + Constants.NEWLINE + "]",dir);
			logger.info("Temp File conecnt in DIR "+ dir +"\n"+content);
			removeFile(Constants.TEMP_FILE,dir);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private boolean uploadQtestResults(Results results) throws InterruptedException, IOException {
		try {
			logger.info(Constants.NEWLINE + Constants.EQUALS_SEPARATOR + Constants.STARTED_QTEST_INTEGRATION
					+ Constants.EQUALS_SEPARATOR + Constants.NEWLINE);
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("qtest_config.xlsx");
			XSSFWorkbook workBook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workBook.getSheetAt(0);
			sheet.removeRow(sheet.getRow(0));
			// Iterate over the worksheet to create hashmap
			for (Row row : sheet) {
				WorkSheetQTestAttributeMapper worksheetRow = new WorkSheetQTestAttributeMapper();
				worksheetRow.setProjectId(row.getCell(1).toString().replace(".0", ""));
				worksheetRow.setModuleId(row.getCell(2).toString().replace(".0", ""));
				worksheetRow.setTestSuiteId(row.getCell(3).toString());
				worksheetRow.setRequirementIds(Arrays.asList(row.getCell(4).toString().replace(".0", "").split(",")));
				worksheetRow.setPhase(row.getCell(5).toString());
				worksheetRow.setAutomationContent(row.getCell(6).toString());
				worksheetRow.setTestType(row.getCell(8).toString());
				worksheetRow.setDuId(row.getCell(9).toString());
				mapWorksheet.put(row.getCell(0).toString(), worksheetRow);
			}
			workBook.close();

			if (isWorkSheetContainsData(results)) {
				logger.info(Constants.WORSHEET_CONTAINS_DATA);
				setQtestRequestBody(results);
				updateUploadurlsFile(Constants.JSON_E2E_OBEJCTS_FOLDER);
				updateUploadurlsFile(Constants.JSON_OBEJCTS_FOLDER);
				Results qTestUploaE2EResults = Runner.path(Constants.UPLOAD_E2E_FEATURE_FILE).parallel(5);
				Results qTestUploadResults = Runner.path(Constants.UPLOAD_FEATURE_FILE).parallel(5);
				generateReport(qTestUploadResults.getReportDir());
			}
			logger.info(Constants.NEWLINE + Constants.EQUALS_SEPARATOR + Constants.COMPLETED_QTEST_INTEGRATION
					+ Constants.EQUALS_SEPARATOR + Constants.NEWLINE);
		} catch (Exception exp) {
			exp.printStackTrace();
			return false;
		}
		return true;
	}

	private boolean isWorkSheetContainsData(Results results) {
		Iterator<String> featureFiles = findDistinctFeatureFiles(results);
		while (featureFiles.hasNext()) {
			Pattern pattern = Pattern.compile(Constants.PATTERN);
			Matcher matcher = pattern.matcher(featureFiles.next());
			if (matcher.find()) {
				logger.info(" Macher "+matcher.group(1));
				if (mapWorksheet.get(matcher.group(1)) != null) {
					return true;
				}
			}
		}
		return false;
	}

	private void setQtestRequestBody(Results results) {
		Iterator<String> featureFiles = findDistinctFeatureFiles(results);
		Map<String, String> qtesturls = new HashMap<>();
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, QTestObjectMapper> qtestFeatures = new HashMap<>();
		String appname = Constants.EMPTY_STRING;
		while (featureFiles.hasNext()) {
			String featureFile = featureFiles.next();
			Pattern pattern = Pattern.compile(Constants.PATTERN);
			Matcher matcher = pattern.matcher(featureFile);
			if (matcher.find()) {
				appname = matcher.group(1);
			}
			Iterator<ScenarioResult> listScenarioIterator = getScenarioIteratorForFeatureFile(results, featureFile);
			logger.info( " Work sheet data "+mapWorksheet.get(appname));
			while (listScenarioIterator.hasNext()) {
				ScenarioResult scenarioResult = listScenarioIterator.next();
				String testCaseName = scenarioResult.getScenario().getNameAndDescription()
						.replace(Constants.TEST, Constants.EMPTY_STRING)
						.replace(Constants.APOSTROPHE, Constants.EMPTY_STRING).trim();
				QTestDataDTO qTestDataDTO = createQtestDataDto(appname);
				QTestObjectMapper qtestObjectMapper = new QTestObjectMapper();
				qtestObjectMapper.setQtestDataDTO(qTestDataDTO);
				qtestObjectMapper.setApplication(Constants.QTEST_APPLICATION_NAME);
				qtestObjectMapper.setAutomationContent(mapWorksheet.get(appname).getAutomationContent());
				qtestObjectMapper.setCategory(Constants.QTEST_CATEGORY);
				qtestObjectMapper.setPhase(mapWorksheet.get(appname).getPhase());
				qtestObjectMapper.setName(testCaseName);
				qtestObjectMapper.setTestAutomationSystem(Constants.QTEST_AUTOMATION_SYSTEM);
				if (requirementId == null) {
					qtestObjectMapper.setRequirementIds(mapWorksheet.get(appname).getRequirementIds());
				} else {
					qtestObjectMapper.setRequirementIds(Arrays.asList(requirementId.split(",")));
				}
				qtestObjectMapper.setQTestEnv(Constants.QTEST_ENV);
				qtestObjectMapper.setPhase(mapWorksheet.get(appname).getPhase());
				qtestObjectMapper.setProjectId(qTestDataDTO);
				qtestObjectMapper.setModuleId(qTestDataDTO);
				qtestObjectMapper.setAutomationReferenceId(qTestDataDTO);
				List<QTestStepsMapper> listqtestTestStepMapper = extractStepsTestResult(results, scenarioResult);

				QTestStepsMapper qtestTestStepMapper = listqtestTestStepMapper.stream()
						.filter(e -> e.getDescription().equals(scenarioResult.getScenario().getNameAndDescription()))
						.findFirst().orElse(null);
				QTestUpdateDTOMapper qTestUpdateDTOMapper = createQTestUpdateDTO(qTestDataDTO, qtestTestStepMapper, appname);
				qtestObjectMapper.setQTestUpdateDTO(qTestUpdateDTOMapper);
				qTestUpdateDTOMapper.setTestSteps(listqtestTestStepMapper);
				qtestFeatures.put(appname + "_" + testCaseName, qtestObjectMapper);
			}
		}

		for (String key : qtestFeatures.keySet()) {
			try {
				String jsonArray = (objectMapper.writeValueAsString(qtestFeatures.get(key)));
				String filename = key.trim() + Constants.JSON_EXTENSION;
				qtesturls.put("url", filename);
				objectMapper.writeValue(Paths.get(Constants.JSON_OBEJCTS_FOLDER + filename).toFile(), jsonArray);
				String qtesturljson = objectMapper.writeValueAsString(qtesturls);
				qtesturljson = Constants.NEWLINE + qtesturljson + ",";

				Path filePath = Paths.get(Constants.JSON_OBEJCTS_FOLDER + Constants.TEMP_FILE);
				if (!Files.exists(filePath)) {
					Files.createFile(filePath);
				}
				Files.write(filePath, qtesturljson.getBytes(), StandardOpenOption.APPEND);

			} catch (JsonProcessingException e) {
				e.printStackTrace();

			} catch (IOException e) {
				logger.error(Constants.IO_EXCEPTION + e);
			}
		}
		for (String key : qtestFeatures.keySet()) {
			try {
				QTestObjectMapper testResults = qtestFeatures.get(key);
				testResults.getQTestUpdateDTO().setTestType(Constants.E2E);
				String jsonArray = (objectMapper.writeValueAsString(testResults));
				String filename = key.trim() + Constants.JSON_EXTENSION;
				qtesturls.put("url", filename);
				objectMapper.writeValue(Paths.get(Constants.JSON_E2E_OBEJCTS_FOLDER + filename).toFile(), jsonArray);
				String qtesturljson = objectMapper.writeValueAsString(qtesturls);
				qtesturljson = Constants.NEWLINE + qtesturljson + ",";

				Path filePath = Paths.get(Constants.JSON_E2E_OBEJCTS_FOLDER + Constants.TEMP_FILE);
				if (!Files.exists(filePath)) {
					Files.createFile(filePath);
				}
				Files.write(filePath, qtesturljson.getBytes(), StandardOpenOption.APPEND);

			} catch (JsonProcessingException e) {
				e.printStackTrace();

			} catch (IOException e) {
				logger.error(Constants.IO_EXCEPTION + e);
			}
		}
	}

	private Iterator<String> findDistinctFeatureFiles(Results results) {
		Set<String> featureFiles = new HashSet<>();
		results.getScenarioResults()
				.forEach(s -> featureFiles.add(s.getScenario().getFeature().getNameAndDescription()));
		logger.info("featureFiles.size() = " + featureFiles.size());
		return featureFiles.iterator();
	}

	private Iterator<ScenarioResult> getScenarioIteratorForFeatureFile(Results results, String featureFile) {
		Stream<ScenarioResult> listScenarioResult = results.getScenarioResults().stream()
				.filter(s -> s.getScenario().getFeature().getNameAndDescription().equals(featureFile));
		return listScenarioResult.iterator();
	}

	private List<QTestStepsMapper> extractStepsTestResult(Results results, ScenarioResult scenarioResult) {
		List<QTestStepsMapper> listqtestTestStepMapper = new ArrayList<>();
		Stream<StepResult> listStepResult = scenarioResult.getStepResults().stream()
				.filter(sr -> sr.getStep().getText().contains(Constants.MATCH)
						|| sr.getStep().getText().contains(Constants.STATUS_200)
						|| sr.getStep().getText().contains(Constants.PRINT_RESPONSE));
		Iterator<StepResult> listStepIterator = listStepResult.iterator();
		StepResult stepResult = null;
		int stepIteration = 0;
		String actualResult = Constants.EMPTY_STRING;
		int order = 0;
		while (listStepIterator.hasNext()) {
			QTestStepsMapper qtestTestStepMapper = new QTestStepsMapper();
			TestStepDTO testStepDTO  = new TestStepDTO();
			stepResult = listStepIterator.next();
			if (stepIteration < 1 && stepResult.getStepLog() != null) {
				actualResult = stepResult.getStepLog().substring(stepResult.getStepLog().indexOf(Constants.PRINT) + 8);
			}
			if (qtestTestStepMapper != null && stepResult != null
					&& !stepResult.getStep().getText().contains(Constants.PRINT_RESPONSE)) {
				order++;
				testStepDTO.setTestStepStatus(
						stepResult.getResult().getStatus().equals(Constants.passed) ? TestStepStatus.PASSED
								: TestStepStatus.FAILED);
				testStepDTO.setDescription(scenarioResult.getScenario().getNameAndDescription());
				testStepDTO.setOrder(order);
				qtestTestStepMapper.setTestStepDTO(testStepDTO);
				qtestTestStepMapper.setDescription(testStepDTO);
				qtestTestStepMapper.setOrder(testStepDTO);
				qtestTestStepMapper.setStatus(stepResult.getResult().getStatus().equals(Constants.passed) ? Constants.PASS
						: Constants.FAIL);
				qtestTestStepMapper.setExpected(stepResult.getStep().getText().replace(Constants.MATCH, Constants.EMPTY_STRING));
				if (testStepDTO.getTestStepStatus().equals(TestStepStatus.PASSED)){
					qtestTestStepMapper.setActualResult(stepResult.getStep().getText().replace(Constants.MATCH, Constants.EMPTY_STRING));
				}else{
					qtestTestStepMapper.setActualResult(actualResult);
				}
				listqtestTestStepMapper.add(qtestTestStepMapper);
			}
			stepIteration++;
		}
		return listqtestTestStepMapper;

	}

	private QTestDataDTO createQtestDataDto(String appname) {
		QTestDataDTO qTestDataDTO = new QTestDataDTO();
		qTestDataDTO.setQTestModuleId(Long.parseLong(mapWorksheet.get(appname).getModuleId()));
		qTestDataDTO.setqTestAutomationRefId(Constants.EMPTY_STRING);
		qTestDataDTO.setQTestProjectId(Long.parseLong(mapWorksheet.get(appname).getProjectId()));
		Date date = new Date();
		qTestDataDTO.setDateTime(date);
		qTestDataDTO.setNotes(Constants.EMPTY_STRING);
		qTestDataDTO.setReason(Constants.EMPTY_STRING);
		qTestDataDTO.setQTestTestSuiteId(Long.parseLong(mapWorksheet.get(appname).getTestSuiteId().replace(".0", "")));
		return qTestDataDTO;
	}

	private QTestUpdateDTOMapper createQTestUpdateDTO(QTestDataDTO qTestDataDTO, QTestStepsMapper qtestTestStepMapper,
			String appname) {
		QTestUpdateDTO qTestUpdateDTO = new QTestUpdateDTO();
		qTestUpdateDTO.setQTestProjectId(qTestDataDTO.getQTestProjectId());
		qTestUpdateDTO.setQTestModuleId(qTestDataDTO.getQTestModuleId());
		qTestUpdateDTO.setQTestTestSuiteId(qTestDataDTO.getQTestTestSuiteId());
		qTestUpdateDTO.setNotes(qTestDataDTO.getNotes());
		String executionStatus = (qtestTestStepMapper != null && qtestTestStepMapper.getStatus() != null
				&& qtestTestStepMapper.getStatus().toString().equalsIgnoreCase(Constants.PASS)) ? Constants.PASS
						: Constants.FAIL;
		qTestUpdateDTO.setStatus(executionStatus);
		qTestUpdateDTO.setQTestBuildMode(Constants.QTEST_ENV);
		qTestUpdateDTO.setReason(qTestDataDTO.getReason());
		qTestUpdateDTO.setqTestAutomationRefId(qTestDataDTO.getqTestAutomationRefId());
		QTestUpdateDTOMapper qtestUpdateDTOMapper = new QTestUpdateDTOMapper();

		qtestUpdateDTOMapper.setNotes(qTestUpdateDTO);
		qtestUpdateDTOMapper.setQTestAutomationRefId(qTestUpdateDTO);
		qtestUpdateDTOMapper.setQTestBuildMode(qTestUpdateDTO);
		qtestUpdateDTOMapper.setQTestProjectId(qTestUpdateDTO);
		qtestUpdateDTOMapper.setQTestTestSuiteId(qTestUpdateDTO);
		qtestUpdateDTOMapper.setStatus(qTestUpdateDTO);
		qtestUpdateDTOMapper.setReason(qTestUpdateDTO);

		qtestUpdateDTOMapper.setTestEnv(environment);
		qtestUpdateDTOMapper.setTestType(mapWorksheet.get(appname).getTestType());
		qtestUpdateDTOMapper.setDuId(mapWorksheet.get(appname).getDuId());

		return qtestUpdateDTOMapper;
	}

}
