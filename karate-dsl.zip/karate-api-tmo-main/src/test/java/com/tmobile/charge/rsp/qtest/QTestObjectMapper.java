package com.tmobile.charge.rsp.qtest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tmobile.tep.qtest.QTestDataDTO;

@JsonIgnoreProperties(value = { "qtestDataDTO" })
public class QTestObjectMapper {

	private String name;
	private String phase;
	private long moduleId;
	private long projectId;
	private String category;
	private String qTestEnv;
	private String description;
	private String application;
	private String automationContent;
	private String testAutomationSystem;
	private String automationReferenceId;

	private QTestDataDTO qtestDataDTO;
	private List<String> requirementIds;
	private QTestUpdateDTOMapper qTestUpdateDTO;
	private List<QTestStepsMapper> testSteps;

	public QTestObjectMapper() {
		super();
	}

	public void setQTestEnv(String qTestEnv) {
		this.qTestEnv = qTestEnv;
	}

	public List<String> getRequirementIds() {
		return requirementIds;
	}

	public void setTestSteps(List<QTestStepsMapper> testSteps) {
		this.testSteps = testSteps;
	}

	public List<QTestStepsMapper> getTestSteps() {
		return testSteps;
	}

	public void setRequirementIds(List<String> requirementIds) {
		this.requirementIds = requirementIds;
	}

	public String getQTestEnv() {
		return qTestEnv;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getApplication() {
		return application;
	}

	public void setTestAutomationSystem(String testAutomationSystem) {
		this.testAutomationSystem = testAutomationSystem;
	}

	public String getTestAutomationSystem() {
		return testAutomationSystem;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getphase() {
		return phase;
	}

	public void setAutomationContent(String automationContent) {
		this.automationContent = automationContent;
	}

	public String getAutomationContent() {
		return automationContent;
	}

	public void setQTestUpdateDTO(QTestUpdateDTOMapper qTestUpdateDTO) {
		this.qTestUpdateDTO = qTestUpdateDTO;
	}

	@JsonProperty("qTestUpdateDTO")
	public QTestUpdateDTOMapper getQTestUpdateDTO() {
		return qTestUpdateDTO;
	}

	public void setQtestDataDTO(QTestDataDTO qtestDataDTO) {
		this.qtestDataDTO = qtestDataDTO;
	}

	public QTestDataDTO getQtestDataDTO() {
		return qtestDataDTO;
	}

	public void setProjectId(QTestDataDTO qtestDataDTO) {
		this.projectId = qtestDataDTO.getQTestProjectId();
	}

	public long getProjectId() {
		return projectId;
	}

	public void setModuleId(QTestDataDTO qtestDataDTO) {
		this.moduleId = qtestDataDTO.getQTestModuleId();
	}

	public long getModuleId() {
		return moduleId;
	}

	public void setAutomationReferenceId(QTestDataDTO qtestDataDTO) {
		this.automationReferenceId = qtestDataDTO.getqTestAutomationRefId();
	}

	public String getAutomationReferenceId() {
		return automationReferenceId;
	}
}
