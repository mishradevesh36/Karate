package com.tmobile.charge.rsp.qtest;

import java.util.List;

public class WorkSheetQTestAttributeMapper {

	private String duId;
	private String phase;
	private String moduleId;
	private String testType;
	private String projectId;
	private String testSuiteId;
	private Boolean isUploadTest;
	private String automationContent;
	private List<String> requirementIds;

	public void setRequirementIds(List<String> requirementIds) {
		this.requirementIds = requirementIds;
	}

	public List<String> getRequirementIds() {
		return requirementIds;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectId() {
		return this.projectId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleId() {
		return this.moduleId;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getPhase() {
		return this.phase;
	}

	public String getAutomationContent() {
		return this.automationContent;
	}

	public void setAutomationContent(String automationContent) {
		this.automationContent = automationContent;
	}

	public String getTestSuiteId() {
		return this.testSuiteId;
	}

	public void setTestSuiteId(String testSuiteId) {
		this.testSuiteId = testSuiteId;
	}

	public Boolean getIsUploadTest() {
		return this.isUploadTest;
	}

	public void setIsUploadTest(Boolean isUploadTest) {
		this.isUploadTest = isUploadTest;
	}

	public String getTestType() {
		return testType;
	}

	public void setTestType(String testType) {
		this.testType = testType;
	}

	public String getDuId() {
		return duId;
	}

	public void setDuId(String duId) {
		this.duId = duId;
	}

	@Override
	public String toString() {
		return "WorkSheetQTestAttributeMapper{" +
				"duId='" + duId + '\'' +
				", phase='" + phase + '\'' +
				", moduleId='" + moduleId + '\'' +
				", testType='" + testType + '\'' +
				", projectId='" + projectId + '\'' +
				", testSuiteId='" + testSuiteId + '\'' +
				", isUploadTest=" + isUploadTest +
				", automationContent='" + automationContent + '\'' +
				", requirementIds=" + requirementIds +
				'}';
	}
}
