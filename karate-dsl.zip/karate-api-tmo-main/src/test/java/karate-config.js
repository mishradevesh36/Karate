function fn() {
	// get system property 'karate.env'
	var env = karate.env;
	// base config JSON
	var config = {}
	//get endpoint passed when integrated with service pipeline
	config.baseUrl = karate.properties['karate.baseurl'];
	//Service Url's
	config.addresslookup_rsp_url = 'https://addresslookup-rsp';
	config.addressupdate_rsp_url = 'https://addressupdate-rsp';
	config.addressverification_rsp_url = 'https://addressverification-rsp';
	config.billdetails_rsp_url = 'https://billdetails-rsp';
	config.billhistory_rsp_url = 'https://billhistory-rsp';
	config.billsummary_rsp_url = 'https://billsummary-rsp';
	config.npanxxlookup_rsp_url = 'https://npanxxlookup-rsp';
	config.numbermanagement_rsp_url = 'https://numbermanagement-rsp';
	config.orderfulfillment_rsp_url = 'https://orderfulfillment-rsp';
	config.passagreement_rsp_url = 'https://passagreement-rsp';
	config.serviceagreement_rsp_url = 'https://serviceagreement-rsp';
	config.subscriber_rsp_url = 'https://subscriber-rsp';
	config.subscribercontract_rsp_url = 'https://subscribercontract-rsp';
	config.subscriberdetail_rsp_url = 'https://subscriberdetail-rsp';
	config.subscriberupdate_rsp_url = 'https://subscriberupdate-rsp';
	config.service_email_rsp_url = 'https://service-email-rsp';
	config.service_sms_rsp_url = 'https://service-sms-rsp';
	config.service_samson_rsp_url = 'https://service-samson-rsp';
	config.sales_metrics_rsp_url = 'https://salesmetrics-rsp';
	config.service_receiptnotification_rsp_url = 'https://service-receiptnotification-rsp';
	config.capability_memo_rsp_url = 'https://capability-memo-rsp';
	config.orderfulfillmentnotifications_rsp_url = 'https://orderfulfillmentnotifications-rsp';
	config.voicereminderjob_rsp_url = 'https://voicereminderjob-rsp';
	config.storesalesmetricsprocessor_rsp_url = 'https://storesalesmetricsprocessor-rsp';
	config.eipvoicereminderftpjob_rsp_url = 'https://eipvoicereminderftpjob-rsp';
	config.experience_receipt_rsp_url = 'https://experience-receipt-rsp';
	config.experience_servicequote_rsp_url = 'https://experience-servicequote-rsp';
	config.processorderconsumer_rsp_url = 'https://processorderconsumer-rsp';
	config.orderfulfillmentprocessor_rsp_url = 'https://orderfulfillmentprocessor-rsp';
	config.cancelbusinessorderprocessor_rsp_url = 'https://cancelbusinessorderprocessor-rsp';
	config.addbandollaradjustment_rsp_url='https://addbandollaradjustment-rsp';

	// Setting QTest URL and Credentials
	//config.uploadUrl = "http://qtestproxy.geo.cf.t-mobile.com/api/qtest/testCaseData";
	config.uploadUrl = "https://qtestproxy2.apps.px-prd02.cf.t-mobile.com/api/qtest/testCaseData";
	config.account = "SVC_PRD_ETPQTest@t-mobile.com";
	config.secret = "";

	//setting domain and tdm env based on the env passed
	if (env == 'ilab02') {
		config.domain = '-ilab02.dev.px-npe02c.cf.t-mobile.com';
		config.tdmEnv = 'ILAB02';
		
		config.originInfo_ban = "960821731";
		config.originInfo_msisdn= "2143088564";
	} else if (env == 'ilab02x') {
		config.domain = '-ilab02.test.px-npe01.cf.t-mobile.com';
		config.tdmEnv = 'ILAB02';
		
		config.originInfo_ban = "960821731";
		config.originInfo_msisdn= "2143088564";
	} else if (env == 'qlab01') {
		config.domain = '-qlab01.test.px-npe02C.cf.t-mobile.com';
		config.tdmEnv = 'QLAB01';
		
		config.originInfo_ban = "617925073";
		config.originInfo_msisdn= "7209459185";
	} else if (env == 'qlab01x') {
		config.domain = '-qlab01.test.px-npe01.cf.t-mobile.com';
		config.tdmEnv = 'QLAB01';
		
		config.originInfo_ban = "617925073";
		config.originInfo_msisdn= "7209459185";
	} else if (env == 'qlab02') {
		config.domain = '-qlab02.test.px-npe02C.cf.t-mobile.com';
		config.tdmEnv = 'QLAB02';
		
		config.originInfo_ban = "973095952";
		config.originInfo_msisdn= "6304300453";
	} else if (env == 'qlab02x') {
		config.domain = '-qlab02.test.px-npe01.cf.t-mobile.com';
		config.tdmEnv = 'QLAB02';
		
		config.originInfo_ban = "973095952";
		config.originInfo_msisdn= "6304300453";
	} else if (env == 'qlab03') {
		config.domain = '-qlab03.test.px-npe02C.cf.t-mobile.com';
		config.tdmEnv = 'QLAB03';
		
		config.originInfo_ban = "973096485";
		config.originInfo_msisdn= "6304303438";
	} else if (env == 'qlab03x') {
		config.domain = '-qlab03.test.px-npe01.cf.t-mobile.com';
		config.tdmEnv = 'QLAB03';
		
		config.originInfo_ban = "973096485";
		config.originInfo_msisdn= "6304303438";
	} else if (env == 'qlab06') {
		config.domain = '-qlab06.test.px-npe02C.cf.t-mobile.com';
		config.tdmEnv = 'QLAB06';
		
		config.originInfo_ban = "617752243";
		config.originInfo_msisdn= "7707837562";
	} else if (env == 'qlab06x') {
		config.domain = '-qlab06.test.px-npe01.cf.t-mobile.com';
		config.tdmEnv = 'QLAB06';
		
		config.originInfo_ban = "617752243";
		config.originInfo_msisdn= "7707837562";
	} else if (env == 'qlab07') {
		config.domain = '-qlab07.test.px-npe02C.cf.t-mobile.com';
		config.tdmEnv = 'QLAB07';
		
		config.originInfo_ban = "970608105";
		config.originInfo_msisdn= "8133893044";
	} else if (env == 'qlab07x') {
		config.domain = '-qlab07.test.px-npe01.cf.t-mobile.com';
		config.tdmEnv = 'QLAB07';
		
		config.originInfo_ban = "970608105";
		config.originInfo_msisdn= "8133893044";
	} else if (env == 'plab01') {
		config.domain = '-plab01.test.px-npe02a.cf.t-mobile.com';
		config.tdmEnv = 'PLAB01';
		
		config.originInfo_ban = "970608105";
		config.originInfo_msisdn= "8133893044";
	} else if (env == 'plab01x') {
		config.domain = '-plab01.test.px-npe02a.cf.t-mobile.com';
		config.tdmEnv = 'PLAB01';

		config.originInfo_ban = "970608105";
		config.originInfo_msisdn= "8133893044";
	}
	config = karate.callSingle(
			'classpath:com/tmobile/charge/rsp/utils/Utility.js', config);
	// Don't waste time waiting for a connection or if servers don't respond within 10 seconds
	karate.configure('readTimeout', 35000);
	return config;
}
